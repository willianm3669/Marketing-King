# KING OF MARKETING — MVP 0.1

Aplicativo web responsivo para o marketing por e-mail da KING OF SUPPLEMENTS. Este é um primeiro projeto executável, com autenticação, banco SQLite persistente, sincronização do catálogo Nuvemshop, geração de rascunhos por OpenAI, edição de conteúdo na prévia e biblioteca de campanhas.

## O que funciona nesta versão

- Login por e-mail e senha definidos por variáveis de ambiente; senha armazenada como hash.
- Sessões e dados persistidos em SQLite.
- Sincronização de até 200 produtos por chamada da API Nuvemshop.
- Geração de conteúdo com OpenAI usando somente produtos selecionados e dados sincronizados.
- Prévia editável e salvamento de campanhas como rascunho.
- Estado de configuração das integrações e registro básico de auditoria.
- Interface responsiva para computador e celular.

## O que ainda precisa ser concluído antes de produção

- Integração completa de envio SendPulse: autenticação, escolha de lista, envio de teste, agendamento, filas, webhooks/eventos e métricas.
- Consentimento e segmentação de contatos, lista de supressão/unsubscribe e fluxo LGPD.
- Testes automatizados, revisão de segurança, política de backup e restauração do SQLite.
- Revisar a configuração da API Nuvemshop com o ID/token corretos e validar os campos da conta.
- Recomenda-se migrar para PostgreSQL se houver múltiplos usuários/instâncias ou volume maior.

**Importante:** esta versão não envia e-mails de marketing. O botão de IA cria apenas rascunhos. Não foi configurado envio automático.

## Requisitos

- Node.js 20+ (ou Docker)
- Conta/aplicação Nuvemshop com acesso à API
- Chave de API OpenAI para geração de texto
- Credenciais SendPulse para a etapa de envio (ainda não ativada nesta versão)

## Rodar localmente

1. Copie `.env.example` para `.env`.
2. Defina `SESSION_SECRET` com uma chave aleatória longa, `ADMIN_EMAIL` e `ADMIN_PASSWORD`.
3. Para ativar IA, configure `OPENAI_API_KEY`.
4. Para sincronizar produtos, configure `NUVEMSHOP_STORE_ID` e `NUVEMSHOP_ACCESS_TOKEN`.
5. Instale dependências e inicie:

```bash
npm install
npm start
```

Acesse `http://localhost:3000`.

## Rodar com Docker / Coolify

1. Crie um repositório Git privado e envie estes arquivos.
2. No Coolify, crie um recurso de aplicação baseado no repositório Git.
3. Use o `Dockerfile` incluído como método de build.
4. Configure as variáveis listadas no `.env.example` no painel de Environment Variables do Coolify.
5. Exponha a porta interna `3000` e ative domínio + HTTPS no Coolify.
6. Configure um volume persistente em `/app/db` para preservar banco e sessões em novos deploys.
7. Antes de colocar em produção, altere as credenciais iniciais e confirme backups do volume.

## Segurança

- Nunca suba `.env` para GitHub.
- Não compartilhe chaves de OpenAI, Nuvemshop ou SendPulse no chat ou em capturas de tela.
- Use senhas fortes e HTTPS.
- Restrinja o acesso administrativo; este MVP foi desenhado inicialmente para um administrador.

## Estrutura

- `src/server.js` — API, autenticação, SQLite e integrações de servidor.
- `public/index.html` — estrutura do painel.
- `public/styles.css` — interface responsiva.
- `public/app.js` — navegação e interações do frontend.
- `db/` — banco persistente criado em execução; não deve ser enviado ao Git.
- `Dockerfile` — build de container para Coolify.
