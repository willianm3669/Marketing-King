import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import session from 'express-session';
import SQLiteStoreFactory from 'connect-sqlite3';
import bcrypt from 'bcryptjs';
import rateLimit from 'express-rate-limit';
import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
if (process.env.NODE_ENV === 'production' && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error('Em produção, configure SESSION_SECRET com pelo menos 32 caracteres.');
}
const SQLiteStore = SQLiteStoreFactory(session);
const db = new Database(path.join(__dirname, '..', 'db', 'king-marketing.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY, name TEXT NOT NULL, price REAL, stock INTEGER, image TEXT, url TEXT, synced_at TEXT);
CREATE TABLE IF NOT EXISTS campaigns (id TEXT PRIMARY KEY, name TEXT NOT NULL, subject TEXT NOT NULL, preheader TEXT DEFAULT '', content_json TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'draft', audience_id TEXT, scheduled_at TEXT, provider_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY, user_email TEXT, action TEXT NOT NULL, details TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
`);

const envAdmin = process.env.ADMIN_EMAIL;
const envPassword = process.env.ADMIN_PASSWORD;
if (envAdmin && envPassword && !db.prepare('SELECT id FROM users WHERE email=?').get(envAdmin.toLowerCase())) {
  db.prepare('INSERT INTO users(email,password_hash) VALUES(?,?)').run(envAdmin.toLowerCase(), bcrypt.hashSync(envPassword, 12));
}

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ["'self'", 'https://fonts.gstatic.com'], imgSrc: ["'self'", 'data:', 'https:'], scriptSrc: ["'self'"], connectSrc: ["'self'"] } }}));
app.use(express.json({ limit: '1mb' }));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: path.join(__dirname, '..', 'db') }),
  secret: process.env.SESSION_SECRET || 'development-only-change-this-session-secret',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 8 * 60 * 60 * 1000 }
}));
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }));

const log = (req, action, details='') => db.prepare('INSERT INTO audit_logs(user_email,action,details) VALUES(?,?,?)').run(req.session?.user?.email || 'system', action, String(details).slice(0,1000));
const auth = (req,res,next) => req.session?.user ? next() : res.status(401).json({ error: 'Faça login para continuar.' });
const integrationStatus = () => ({
  openai: Boolean(process.env.OPENAI_API_KEY),
  nuvemshop: Boolean(process.env.NUVEMSHOP_STORE_ID && process.env.NUVEMSHOP_ACCESS_TOKEN),
  sendpulse: Boolean(process.env.SENDPULSE_CLIENT_ID && process.env.SENDPULSE_CLIENT_SECRET)
});

app.get('/api/health', (req,res) => res.json({ ok:true, app:'KING OF MARKETING', version:'0.1.0' }));
app.post('/api/auth/login', async (req,res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!email || !password) return res.status(400).json({error:'Informe e-mail e senha.'});
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !await bcrypt.compare(password,user.password_hash)) return res.status(401).json({error:'E-mail ou senha inválidos.'});
  req.session.user = {id:user.id,email:user.email};
  log(req,'login');
  res.json({ok:true,email:user.email});
});
app.post('/api/auth/logout', (req,res) => req.session.destroy(() => res.json({ok:true})));
app.get('/api/auth/me', auth, (req,res) => res.json({user:req.session.user}));
app.get('/api/dashboard', auth, (req,res) => {
  const campaigns = db.prepare('SELECT status, COUNT(*) count FROM campaigns GROUP BY status').all();
  const products = db.prepare('SELECT COUNT(*) count FROM products').get().count;
  const recent = db.prepare('SELECT id,name,subject,status,created_at FROM campaigns ORDER BY created_at DESC LIMIT 6').all();
  res.json({campaigns,products,recent,integrations:integrationStatus()});
});
app.get('/api/settings/status', auth, (req,res) => res.json({integrations:integrationStatus(), configuredFromServer:true}));

async function nuvemshopRequest(resource) {
  const storeId = process.env.NUVEMSHOP_STORE_ID;
  const token = process.env.NUVEMSHOP_ACCESS_TOKEN;
  if (!storeId || !token) throw new Error('Configure NUVEMSHOP_STORE_ID e NUVEMSHOP_ACCESS_TOKEN nas variáveis do servidor.');
  const response = await fetch(`https://api.tiendanube.com/v1/${encodeURIComponent(storeId)}/${resource}`, {
    headers: { Authentication: `bearer ${token}`, 'User-Agent': process.env.NUVEMSHOP_USER_AGENT || 'KING OF MARKETING (contato@kingof.com.br)', 'Content-Type':'application/json' }
  });
  if (!response.ok) throw new Error(`Nuvemshop respondeu HTTP ${response.status}. Verifique as credenciais e permissões da aplicação.`);
  return response.json();
}
app.get('/api/products', auth, (req,res) => res.json(db.prepare('SELECT * FROM products ORDER BY name').all()));
app.post('/api/products/sync', auth, async (req,res) => {
  try {
    const items = await nuvemshopRequest('products?per_page=200');
    const upsert = db.prepare(`INSERT INTO products(id,name,price,stock,image,url,synced_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET name=excluded.name,price=excluded.price,stock=excluded.stock,image=excluded.image,url=excluded.url,synced_at=CURRENT_TIMESTAMP`);
    const transaction = db.transaction((list) => {
      for (const p of list) {
        const variants = p.variants || [];
        const prices = variants.map(v => Number(v.price)).filter(n => Number.isFinite(n) && n > 0);
        const stock = variants.reduce((sum,v) => sum + (Number(v.stock) || 0),0);
        upsert.run(String(p.id),p.name || 'Produto sem nome',prices.length ? Math.min(...prices) : null,stock,p.images?.[0]?.src || '',p.canonical_url || '',new Date().toISOString());
      }
    });
    transaction(items);
    log(req,'nuvemshop_product_sync',`count=${items.length}`);
    res.json({ok:true,count:items.length});
  } catch (e) { res.status(502).json({error:e.message}); }
});

app.post('/api/ai/generate', auth, async (req,res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(400).json({error:'Configure OPENAI_API_KEY no servidor para ativar a geração por IA.'});
  const { productIds=[], objective='Apresentar produtos e incentivar a compra', tone='Direto, brasileiro e confiável', offer='Não invente descontos nem condições comerciais' } = req.body || {};
  if (!Array.isArray(productIds) || productIds.length > 20) return res.status(400).json({error:'Selecione até 20 produtos.'});
  const products = productIds.length ? db.prepare(`SELECT id,name,price,stock,image,url FROM products WHERE id IN (${productIds.map(()=>'?').join(',')})`).all(...productIds) : [];
  if (productIds.length && products.length !== new Set(productIds.map(String)).size) return res.status(400).json({error:'Um ou mais produtos não foram encontrados no catálogo sincronizado.'});
  const productContext = products.map(p => ({...p, price: p.price == null ? null : Number(p.price), stock: Number(p.stock || 0)}));
  const prompt = `Você é estrategista de e-mail marketing da KING OF SUPPLEMENTS, loja brasileira de suplementos. Gere uma campanha de e-mail em português brasileiro. Objetivo: ${String(objective).slice(0,500)}. Tom: ${String(tone).slice(0,200)}. Orientação de oferta: ${String(offer).slice(0,500)}. Use somente os dados de produtos abaixo. Não invente preço, estoque, cupom, desconto, frete ou benefício. Se o estoque for 0, não promova o produto. Retorne SOMENTE JSON válido com: subject (máx 60 caracteres), preheader (máx 100), headline, intro, cta_text, cta_url (somente URL de produto fornecida ou vazio), sections (array de objetos com heading e text), disclaimer. Produtos: ${JSON.stringify(productContext)}`;
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', { method:'POST', headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'}, body:JSON.stringify({model:process.env.OPENAI_MODEL || 'gpt-4.1-mini',temperature:0.6,response_format:{type:'json_object'},messages:[{role:'system',content:'Você gera conteúdo de marketing honesto. Nunca crie fatos comerciais. Saída JSON.'},{role:'user',content:prompt}]}) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error?.message || `OpenAI HTTP ${response.status}`);
    const content = JSON.parse(data.choices?.[0]?.message?.content || '{}');
    log(req,'ai_campaign_copy',`products=${productIds.length}`);
    res.json({ok:true,campaign:content,products:productContext});
  } catch(e) { res.status(502).json({error:`Não foi possível gerar a campanha: ${e.message}`}); }
});

app.get('/api/campaigns', auth, (req,res) => res.json(db.prepare('SELECT id,name,subject,status,audience_id,scheduled_at,created_at,updated_at FROM campaigns ORDER BY created_at DESC').all()));
app.post('/api/campaigns', auth, (req,res) => {
  const {name,subject,preheader='',content={},audienceId=null} = req.body || {};
  if (!String(name||'').trim() || !String(subject||'').trim()) return res.status(400).json({error:'Nome e assunto são obrigatórios.'});
  const id = crypto.randomUUID();
  db.prepare('INSERT INTO campaigns(id,name,subject,content_json,audience_id) VALUES(?,?,?,?,?)').run(id,String(name).slice(0,160),String(subject).slice(0,160),JSON.stringify({preheader, ...content}),audienceId);
  log(req,'campaign_created',id);
  res.status(201).json({ok:true,id});
});
app.get('/api/campaigns/:id', auth, (req,res) => {
  const row = db.prepare('SELECT * FROM campaigns WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({error:'Campanha não encontrada.'});
  res.json({...row,content:JSON.parse(row.content_json)});
});
app.patch('/api/campaigns/:id', auth, (req,res) => {
  const row = db.prepare('SELECT * FROM campaigns WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({error:'Campanha não encontrada.'});
  if (row.status === 'sent' || row.status === 'sending') return res.status(409).json({error:'Campanha já enviada ou em envio não pode ser editada.'});
  const name = String(req.body?.name ?? row.name).slice(0,160);
  const subject = String(req.body?.subject ?? row.subject).slice(0,160);
  const content = req.body?.content ?? JSON.parse(row.content_json);
  db.prepare('UPDATE campaigns SET name=?,subject=?,content_json=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(name,subject,JSON.stringify(content),row.id);
  log(req,'campaign_updated',row.id);
  res.json({ok:true});
});
app.get('/api/audit', auth, (req,res) => res.json(db.prepare('SELECT action,details,created_at FROM audit_logs ORDER BY id DESC LIMIT 100').all()));

app.use(express.static(path.join(__dirname,'..','public')));
app.get('*', (req,res) => res.sendFile(path.join(__dirname,'..','public','index.html')));
app.use((err,req,res,next) => { console.error(err); res.status(500).json({error:'Erro interno. Consulte os logs do servidor.'}); });

const port = Number(process.env.PORT || 3000);
app.listen(port,'0.0.0.0',() => console.log(`KING OF MARKETING disponível na porta ${port}`));
